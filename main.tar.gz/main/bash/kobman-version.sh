#!/usr/bin/env bash


function __kob_version {
	echo ""
	__kobdevops_echo_yellow "KOBDEVOPS ${KOBDEVOPS_VERSION}"
}
